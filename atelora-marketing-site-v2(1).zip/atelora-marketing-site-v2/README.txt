Atelora Marketing Site v2

Included:
- index.html
- assets/hero-main-showcase.png
- assets/feature-course-author.png
- assets/feature-live-quiz.png
- assets/feature-learner-journey.png
- assets/feature-analytics.png
- assets/feature-course-player.png

Updates in v2:
- More premium landing page layout
- Single dashboard hero image
- Additional sections: logo strip, stats, value cards, FAQ, and enhanced CTA
- Improved copy and structure for a stronger SaaS-style marketing site
- Static, responsive, GitHub-ready folder structure
