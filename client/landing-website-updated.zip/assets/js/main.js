(() => {
  const menu = document.getElementById('mobile-menu');
  const openButton = document.querySelector('[aria-controls="mobile-menu"]');
  if (!menu || !openButton) return;

  const panel = menu.querySelector('[role="dialog"]');
  const closeButtons = menu.querySelectorAll('button[aria-label="Close menu"]');
  const menuLinks = menu.querySelectorAll('a[href^="#"]');

  const openMenu = () => {
    menu.setAttribute('aria-hidden', 'false');
    openButton.setAttribute('aria-expanded', 'true');
    menu.classList.remove('pointer-events-none', 'opacity-0');
    menu.classList.add('pointer-events-auto', 'opacity-100');
    panel?.classList.remove('-translate-y-3', 'opacity-0');
    panel?.classList.add('translate-y-0', 'opacity-100');
    menu.querySelector(':scope > button')?.classList.remove('pointer-events-none');
    document.body.classList.add('menu-open');
  };

  const closeMenu = () => {
    menu.setAttribute('aria-hidden', 'true');
    openButton.setAttribute('aria-expanded', 'false');
    menu.classList.add('pointer-events-none', 'opacity-0');
    menu.classList.remove('pointer-events-auto', 'opacity-100');
    panel?.classList.add('-translate-y-3', 'opacity-0');
    panel?.classList.remove('translate-y-0', 'opacity-100');
    menu.querySelector(':scope > button')?.classList.add('pointer-events-none');
    document.body.classList.remove('menu-open');
  };

  openButton.addEventListener('click', () => {
    openButton.getAttribute('aria-expanded') === 'true' ? closeMenu() : openMenu();
  });
  closeButtons.forEach((button) => button.addEventListener('click', closeMenu));
  menuLinks.forEach((link) => link.addEventListener('click', closeMenu));
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && openButton.getAttribute('aria-expanded') === 'true') closeMenu();
  });
})();
