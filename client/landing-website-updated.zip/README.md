# Scorms.ai static website clone

This is a cleaned, framework-free static version of the supplied website download.

## Structure

- `index.html` — page markup
- `assets/css/styles.css` — all site styling
- `assets/js/main.js` — mobile menu behaviour
- `assets/images/` — local website images
- `assets/fonts/` — local Geist webfont
- `manifest.webmanifest` — local app metadata

## Run locally

You can open `index.html` directly, or serve the folder with a small local server:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

No Next.js, npm install, build process, or external asset CDN is required for the page layout. External links and mail links remain external by design.
