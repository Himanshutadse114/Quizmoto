import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import axios from 'axios';
import { ArrowLeft, Trophy, Users, Calendar, ChevronDown, ChevronUp, Download, Crown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Reports = () => {
    const [reports, setReports] = useState([]);
    const [loading, setLoading] = useState(true);
    const [expandedId, setExpandedId] = useState(null);
    const { token } = useAuth();
    const navigate = useNavigate();

    const API_URL = `/api/quizzes/reports/all`;

    useEffect(() => {
        const fetchReports = async () => {
            try {
                const res = await axios.get(API_URL, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setReports(res.data);
                setLoading(false);
            } catch (err) {
                console.error(err);
                setLoading(false);
            }
        };
        fetchReports();
    }, [token]);

    const downloadCSV = (session) => {
        const quizTitle = session.Quiz?.title || 'Unknown Quiz';
        const date = new Date(session.updatedAt).toLocaleDateString('en-US');
        const sorted = [...session.players].sort((a, b) => b.score - a.score);

        const rows = [
            ['Rank', 'Nickname', 'Score', 'Team', 'Session Date', 'Quiz'],
            ...sorted.map((p, i) => [
                i + 1,
                p.nickname,
                p.score,
                p.teamName || '-',
                date,
                quizTitle
            ])
        ];

        const csvContent = rows.map(r => r.map(v => `"${v}"`).join(',')).join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${quizTitle.replace(/\s+/g, '_')}_${date.replace(/\//g, '-')}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-screen gap-4">
            <div className="w-10 h-10 border-2 border-white/20 border-t-white rounded-full animate-spin" />
            <p className="text-white/50 text-sm font-medium">Loading reports...</p>
        </div>
    );

    return (
        <div className="p-4 md:p-8 max-w-5xl mx-auto relative z-10">
            {/* Header */}
            <header className="flex items-center gap-4 mb-8 pb-4 border-b border-white/10">
                <button onClick={() => navigate('/dashboard')} className="p-2 bg-white/8 hover:bg-white/15 rounded-lg transition-all">
                    <ArrowLeft size={20} />
                </button>
                <div>
                    <h1 className="text-2xl font-bold tracking-tight">Session Reports</h1>
                    <p className="text-white/40 text-xs mt-0.5">Review past game performance</p>
                </div>
            </header>

            {reports.length > 0 ? (
                <div className="space-y-3">
                    {reports.map((session, idx) => {
                        const date = new Date(session.updatedAt).toLocaleDateString('en-US', {
                            month: 'short', day: 'numeric', year: 'numeric',
                            hour: '2-digit', minute: '2-digit'
                        });
                        const sorted = [...session.players].sort((a, b) => b.score - a.score);
                        const winner = sorted[0];
                        const isExpanded = expandedId === session.id;

                        return (
                            <motion.div
                                key={session.id}
                                initial={{ opacity: 0, y: 12 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden"
                            >
                                {/* Session Summary Row */}
                                <div className="flex items-center justify-between p-5 gap-4">
                                    <div className="flex items-center gap-4 min-w-0">
                                        <div className="bg-kahoot-purple/20 p-3 rounded-xl shrink-0">
                                            <Trophy size={20} className="text-kahoot-yellow" />
                                        </div>
                                        <div className="min-w-0">
                                            <h3 className="font-semibold text-white text-base truncate">
                                                {session.Quiz?.title || 'Unknown Quiz'}
                                            </h3>
                                            <div className="flex items-center gap-3 mt-1 text-xs text-white/40">
                                                <span className="flex items-center gap-1"><Calendar size={11} /> {date}</span>
                                                <span className="flex items-center gap-1"><Users size={11} /> {session.players.length} players</span>
                                                {winner && <span className="flex items-center gap-1"><Crown size={11} className="text-yellow-400" /> {winner.nickname} ({winner.score} pts)</span>}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                        <button
                                            onClick={() => downloadCSV(session)}
                                            title="Download CSV"
                                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/8 border border-white/10 hover:bg-white/15 transition-all"
                                        >
                                            <Download size={13} />
                                            CSV
                                        </button>
                                        <button
                                            onClick={() => setExpandedId(isExpanded ? null : session.id)}
                                            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/8 border border-white/10 hover:bg-white/15 transition-all"
                                        >
                                            {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                                            {isExpanded ? 'Hide' : 'Details'}
                                        </button>
                                    </div>
                                </div>

                                {/* Expanded Player Table */}
                                <AnimatePresence>
                                    {isExpanded && (
                                        <motion.div
                                            initial={{ height: 0, opacity: 0 }}
                                            animate={{ height: 'auto', opacity: 1 }}
                                            exit={{ height: 0, opacity: 0 }}
                                            transition={{ duration: 0.2 }}
                                            className="overflow-hidden"
                                        >
                                            <div className="border-t border-white/10 p-4">
                                                <table className="w-full text-sm">
                                                    <thead>
                                                        <tr className="text-white/40 text-xs uppercase tracking-wider">
                                                            <th className="text-left py-2 px-3 font-medium">Rank</th>
                                                            <th className="text-left py-2 px-3 font-medium">Player</th>
                                                            {session.players.some(p => p.teamName) && (
                                                                <th className="text-left py-2 px-3 font-medium">Team</th>
                                                            )}
                                                            <th className="text-right py-2 px-3 font-medium">Score</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="divide-y divide-white/5">
                                                        {sorted.map((player, rank) => (
                                                            <tr
                                                                key={player.id || player.nickname}
                                                                className={rank === 0 ? 'bg-yellow-400/5' : ''}
                                                            >
                                                                <td className="py-2.5 px-3 text-white/40 font-medium w-12">
                                                                    {rank === 0 ? (
                                                                        <Crown size={14} className="text-yellow-400" />
                                                                    ) : (
                                                                        <span className={rank < 3 ? 'text-white/60' : ''}>{rank + 1}</span>
                                                                    )}
                                                                </td>
                                                                <td className="py-2.5 px-3">
                                                                    <div className="flex items-center gap-2">
                                                                        {player.avatar && <span className="text-base">{player.avatar}</span>}
                                                                        <span className="font-medium text-white/90">{player.nickname}</span>
                                                                    </div>
                                                                </td>
                                                                {session.players.some(p => p.teamName) && (
                                                                    <td className="py-2.5 px-3 text-white/50 text-xs">{player.teamName || '-'}</td>
                                                                )}
                                                                <td className="py-2.5 px-3 text-right">
                                                                    <span className="font-bold tabular-nums">{player.score.toLocaleString()}</span>
                                                                    <span className="text-white/30 text-xs ml-1">pts</span>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </motion.div>
                        );
                    })}
                </div>
            ) : (
                <div className="text-center py-20 bg-white/3 rounded-2xl border border-dashed border-white/10">
                    <Trophy size={40} className="mx-auto text-white/15 mb-4" />
                    <h2 className="text-lg font-semibold text-white/30">No completed sessions yet</h2>
                    <p className="text-white/20 text-sm mt-1">Finish a game session to see reports here.</p>
                </div>
            )}
        </div>
    );
};

export default Reports;
