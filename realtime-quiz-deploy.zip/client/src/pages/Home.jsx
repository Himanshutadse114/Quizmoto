import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

const Home = () => {
    const navigate = useNavigate();

    return (
        <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center relative overflow-hidden">
            <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="z-10 w-full max-w-lg"
            >
                <motion.h1
                    className="text-5xl sm:text-6xl md:text-7xl font-black mb-4 tracking-tighter italic drop-shadow-2xl"
                    style={{ WebkitTextStroke: '1px white' }}
                >
                    Awareness<span className="text-kahoot-yellow">!</span>
                </motion.h1>
                <p className="text-base md:text-lg font-bold mb-8 md:mb-10 opacity-80 tracking-wide uppercase">
                    Real-Time Quiz Experience
                </p>

                <div className="flex flex-col sm:flex-row gap-4 w-full px-4 sm:px-0 max-w-lg mx-auto">
                    <motion.button
                        whileHover={{ scale: 1.05, translateY: -3 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => navigate('/join')}
                        className="flex-1 bg-white text-kahoot-purple font-black py-5 px-10 rounded-xl text-xl shadow-[0_6px_0_0_rgba(255,255,255,0.3)] hover:shadow-none hover:translate-y-1 transition-all"
                    >
                        Join Game
                    </motion.button>

                    <motion.button
                        whileHover={{ scale: 1.05, translateY: -3 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => navigate('/login')}
                        className="flex-1 bg-kahoot-blue text-white font-black py-5 px-10 rounded-xl text-xl shadow-[0_6px_0_0_rgba(19,104,206,0.3)] hover:shadow-none hover:translate-y-1 transition-all"
                    >
                        Host Quiz
                    </motion.button>
                </div>
            </motion.div>

            <footer className="mt-12 md:absolute md:bottom-8 opacity-40 text-[10px] md:text-sm font-bold tracking-widest uppercase">
                &copy; 2024 Awareness! &bull; Built for Speed
            </footer>
        </div>
    );
};

export default Home;
